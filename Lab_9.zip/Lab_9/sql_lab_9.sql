{{ config(materialized='table') }}

select *
from {{ ref('stg_customers') }}

{{ config(materialized='table') }}

select *
from {{ ref('stg_employees') }}

{{ config(materialized='table') }}

select *
from {{ ref('stg_offices') }}

{{ config(materialized='table') }}

select
    p.product_id,
    p.product_name,
    p.product_line,
    pl.text_description as product_line_description,
    p.product_scale,
    p.product_vendor,
    p.buy_price,
    p.MSRP
from {{ ref('stg_products') }} p
left join {{ ref('stg_productlines') }} pl
    on p.product_line = pl.product_line

{{ config(materialized='table') }}

select
    o.order_id,
    o.order_date,
    o.order_status,
    o.customer_id,
    c.customer_name,
    c.sales_rep_id as employee_id,
    e.FIRSTNAME || ' ' || e.LASTNAME as employee_name,
    e.office_id,
    od.product_id,
    p.product_name,
    p.buy_price,
    od.quantity,
    (od.quantity * od.price_each) as total_amount
from {{ ref('stg_orders') }} o
join {{ ref('stg_orderdetails') }} od
    on o.order_id = od.order_id
join {{ ref('dim_customers') }} c
    on o.customer_id = c.customer_id
left join {{ ref('dim_employees') }} e
    on c.sales_rep_id = e.employee_id
join {{ ref('dim_products') }} p
    on od.product_id = p.product_id

{{ config(materialized='view') }}

select
    CUSTOMERNUMBER as customer_id,
    CUSTOMERNAME as customer_name,
    CONTACTFIRSTNAME as contact_first_name,
    CONTACTLASTNAME as contact_last_name,
    PHONE,
    ADDRESSLINE1 as address_line1,
    ADDRESSLINE2 as address_line2,
    CITY,
    STATE,
    POSTALCODE as postal_code,
    COUNTRY,
    SALESREPEMPLOYEENUMBER as sales_rep_id,
    CREDITLIMIT as credit_limit
from {{ source('sales', 'customers') }}

{{ config(materialized='view') }}

select
    EMPLOYEENUMBER as employee_id,
    FIRSTNAME,
    LASTNAME,
    EXTENSION,
    EMAIL,
    OFFICECODE as office_id,
    REPORTSTO as reports_to,
    JOBTITLE as job_title
from {{ source('sales', 'employees') }}

{{ config(materialized='view') }}

select
    OFFICECODE as office_id,
    CITY,
    PHONE,
    ADDRESSLINE1 as address_line1,
    ADDRESSLINE2 as address_line2,
    STATE,
    COUNTRY,
    POSTALCODE as postal_code,
    TERRITORY
from {{ source('sales', 'offices') }}

{{ config(materialized='view') }}

select
    ORDERNUMBER as order_id,
    PRODUCTCODE as product_id,
    QUANTITYORDERED as quantity,
    PRICEEACH as price_each,
    ORDERLINENUMBER as order_line_number
from {{ source('sales', 'orderdetails') }}

{{ config(materialized='view') }}

select
    ORDERNUMBER as order_id,
    ORDERDATE as order_date,
    REQUIREDDATE as required_date,
    SHIPPEDDATE as shipped_date,
    STATUS as order_status,
    CUSTOMERNUMBER as customer_id
from {{ source('sales', 'orders') }}

{{ config(materialized='view') }}

select
    PRODUCTLINE as product_line,
    TEXTDESCRIPTION as text_description,
    HTMLDESCRIPTION as html_description
from {{ source('sales', 'productlines') }}

{{ config(materialized='view') }}

select
    PRODUCTCODE as product_id,
    PRODUCTNAME as product_name,
    PRODUCTLINE as product_line,
    PRODUCTSCALE as product_scale,
    PRODUCTVENDOR as product_vendor,
    PRODUCTDESCRIPTION as product_description,
    QUANTITYINSTOCK as quantity_in_stock,
    BUYPRICE as buy_price,
    MSRP
from {{ source('sales', 'products') }}
