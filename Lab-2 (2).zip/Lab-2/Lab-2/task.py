import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Load processed data
df = pd.read_csv("data_warehouse/processed_sales_data.csv")

# Feature engineering
customer_df = df.groupby('customer_id').agg(
    total_purchase=('total_revenue', 'sum'),
    purchase_frequency=('product_id', 'count'),
    avg_transaction_value=('total_revenue', 'mean')
).reset_index()

# Fill missing values with 0
customer_df.fillna(0, inplace=True)

# Normalize features
scaler = StandardScaler()
scaled_features = scaler.fit_transform(customer_df[['total_purchase', 'purchase_frequency', 'avg_transaction_value']])


kmeans = KMeans(n_clusters=2, random_state=42)
customer_df['vip_cluster'] = kmeans.fit_predict(scaled_features)

# Determine which cluster is VIP (based on higher total_purchase)
cluster_summary = customer_df.groupby('vip_cluster')['total_purchase'].mean()
vip_label = cluster_summary.idxmax()

customer_df['VIP_Status'] = customer_df['vip_cluster'].apply(lambda x: 'VIP' if x == vip_label else 'Non-VIP')

# Drop intermediate clustering column
customer_df.drop(columns=['vip_cluster'], inplace=True)


# Merge VIP tags back into original processed sales data
enriched_df = df.merge(customer_df[['customer_id', 'VIP_Status']], on='customer_id', how='left')

# Save back to raw-like data source or warehouse
enriched_path = "data_warehouse/processed_sales_with_vip.csv"
enriched_df.to_csv(enriched_path, index=False)

print(f"Enriched data with VIP status saved to {enriched_path}")


print(customer_df['VIP_Status'].value_counts())

