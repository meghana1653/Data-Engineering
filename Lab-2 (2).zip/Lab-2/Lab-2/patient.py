# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 10:50:00 2025

@author: Mohan
"""

import os
import pandas as pd
import json
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Ensure warning fix for KMeans on Windows
os.environ["OMP_NUM_THREADS"] = "1"

# Step 1: Load Data
patients = pd.read_csv("C:/Users/Mohan/Downloads/Lab-2/Lab-2/raw_data/patients_data_with_doctor.csv")
doctors = pd.read_csv("C:/Users/Mohan/Downloads/Lab-2/Lab-2/raw_data/doctors_info.csv")
with open("C:/Users/Mohan/Downloads/Lab-2/Lab-2/raw_data/patient_feedback.json", "r") as f:
    feedback = pd.DataFrame(json.load(f))

# Step 2: Clean Data
for df in [patients, doctors, feedback]:
    df.dropna(inplace=True)

# Step 3: Merge Data
df = patients.merge(doctors, on="doctor_id", how="left") \
             .merge(feedback, on=["patient_id"], how="left")

# Step 4: Feature Engineering
doctor_avg_feedback = df.groupby("doctor_id")["patient_feedback_score"].mean().reset_index()
doctor_avg_feedback.rename(columns={"patient_feedback_score": "avg_feedback_score"}, inplace=True)

df = df.merge(doctor_avg_feedback, on="doctor_id", how="left")

# Step 5: Classification (KMeans example)
features = df[["avg_feedback_score"]].drop_duplicates()
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

kmeans = KMeans(n_clusters=2, random_state=42)
features["PerformanceCluster"] = kmeans.fit_predict(scaled_features)

# Map clusters to labels
cluster_map = features.groupby("PerformanceCluster")["avg_feedback_score"].mean().sort_values().reset_index()
cluster_labels = {cluster_map.iloc[0,0]: "Low Performer", cluster_map.iloc[1,0]: "High Performer"}
features["PerformanceLabel"] = features["PerformanceCluster"].map(cluster_labels)

df = df.merge(features[["avg_feedback_score", "PerformanceLabel"]], on="avg_feedback_score", how="left")

# Step 6: Save Output
os.makedirs("data_warehouse", exist_ok=True)
df.to_csv("data_warehouse/processed_patients_with_performance.csv", index=False)

print(df[["doctor_id", "avg_feedback_score", "PerformanceLabel"]].drop_duplicates())
